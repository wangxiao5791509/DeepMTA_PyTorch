# Path to SALICON raw data
pathToImages = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/image'
pathToMapsTrain = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/attention_map'
pathToMapsVal = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/attention_map'

# Path to processed data. Created using preprocess.py
pathToResizedImagesTrain = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/image'
pathToResizedMapsTrain = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/attention_map'
pathToResizedTargetObjectTrain = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/target_objects/first_frame'


pathToResizedImagesVal = pathToResizedImagesTrain
pathToResizedMapsVal = pathToResizedMapsTrain


pathToResizedImagesTest = '/home/wangxiao/Downloads/test_dataset/global_Attention_generation_train_dataset/image'

