import numpy as np
import torch
from torch.autograd import Variable
import torch.nn.functional as F
from ipdb import set_trace
from .utils import get_subwindow_tracking, generate_anchor 
from .config import TrackerConfig 
import torch.nn as nn
import cv2
import pdb 
import os 
import sys 
sys.path.insert(0, '/home/wangxiao/Documents/deepMTA_project/DeepMTA_TCSVT_project/trackers/dcynet_modules_adaptis/')
from generator import DC_adaIS_Generator 
from utils import * 
from skimage import measure
import torchvision.transforms as transforms
from PIL import Image
generator_path = '/home/wangxiao/Documents/deepMTA_project/DeepMTA_TCSVT_project/trackers/dcynet_modules_adaptis/15_generator_dcyNet_adaIS_1e4.pkl'
dcynet_adais_Generator = DC_adaIS_Generator()
dcynet_adais_Generator.load_state_dict(torch.load(generator_path))
dcynet_adais_Generator.cuda()

print(dcynet_adais_Generator)
# pdb.set_trace() 

mask_size = 300 
to_tensor = transforms.ToTensor()


def SiamRPN_init(im, target_pos, target_sz, videoName, frameIndex, cfg):
    state = dict()
    state['im_h'] = im.shape[0]
    state['im_w'] = im.shape[1]

    state_global = dict()
    state_global['im_h'] = im.shape[0]
    state_global['im_w'] = im.shape[1]

    state_global_1 = dict()
    state_global_1['im_h'] = im.shape[0]
    state_global_1['im_w'] = im.shape[1]

    

    # set the tracker_config
    p = TrackerConfig()
    p.update(cfg)

    if p.adaptive:
        if ((target_sz[0] * target_sz[1]) / float(state['im_h'] * state['im_w'])) < 0.004:
            p.instance_size = 287
        else:
            p.instance_size = 271
        p.score_size = (p.instance_size - p.exemplar_size) // p.total_stride + 1

    p.anchor = generate_anchor(p.total_stride, p.scales, p.ratios, int(p.score_size))
    avg_chans = np.mean(im, axis=(0, 1))

    window = np.outer(np.hanning(p.score_size), np.hanning(p.score_size))
    window = np.tile(window.flatten(), p.anchor_num)

    state['device'] = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state['p'] = p
    state['avg_chans'] = avg_chans
    state['window'] = window
    state['target_pos'] = target_pos
    state['target_sz'] = target_sz
    state['score'] = 1.0
    state['atttentonMAP'] = 0 
    state['videoName'] = videoName 
    state['frameIdx'] = frameIndex 
    state['failue_times'] = 0 
    state['goback_flag'] = False 


    state_global['device'] = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state_global['p'] = p
    state_global['avg_chans'] = avg_chans
    state_global['window'] = window
    state_global['target_pos'] = target_pos
    state_global['target_sz'] = target_sz
    state_global['score'] = 1.0
    state_global['failue_times'] = 0 


    state_global_1['device'] = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    state_global_1['p'] = p
    state_global_1['avg_chans'] = avg_chans
    state_global_1['window'] = window
    state_global_1['target_pos'] = target_pos
    state_global_1['target_sz'] = target_sz
    state_global_1['score'] = 1.0
    state_global_1['failue_times'] = 0 


    # pdb.set_trace() 

    init_targetPatch = im[int(target_pos[1]-target_sz[1]/2):int(target_pos[1]+target_sz[1]/2), int(target_pos[0]-target_sz[0]/2):int(target_pos[0]+target_sz[0]/2), :]
    # init_targetPatch = cv2.resize(init_targetPatch, (100, 100)) 
    # cv2.imwrite('./init_targetPatch.png', init_targetPatch) 
    state['init_targetPatch'] = init_targetPatch
    state_global['init_targetPatch'] = init_targetPatch 
    state_global_1['init_targetPatch'] = init_targetPatch 

    ##################################################################################
    ##################################################################################
    ##################################################################################

    im_trans = cv2.resize(im, (300, 300))
    t_template = cv2.resize(init_targetPatch, (100, 100)) 

    im_trans = to_variable(torch.unsqueeze(to_tensor(im_trans), dim=0), False)
    t_template = to_variable(torch.unsqueeze(to_tensor(t_template), dim=0), False) 

    coords = torch.from_numpy(state['target_pos']) 
    coords = coords.unsqueeze(0).type(torch.FloatTensor) 


    out = dcynet_adais_Generator(im_trans, t_template, coords)
    out = nn.functional.interpolate(out, size=[im.shape[0], im.shape[1]])
    map_out = out.cpu().data.squeeze(0)
    pilTrans = transforms.ToPILImage()
    pilImg = pilTrans(map_out) 
    dynamic_atttentonMAP = np.asarray(pilImg)
    dynamic_atttentonMAP = cv2.resize(dynamic_atttentonMAP, (im.shape[1], im.shape[0]))
    state_global['atttentonMAP'] = dynamic_atttentonMAP
    state['atttentonMAP'] = dynamic_atttentonMAP

    return state, state_global, state_global_1 







def SiamRPN_track(state, state_global, state_global_1, im, temp_mem):
    p         = state['p']
    avg_chans = state['avg_chans']
    window    = state['window']
    old_pos   = state['target_pos']
    old_sz    = state['target_sz']
    dev       = state['device']
    
    wc_z = old_sz[1] + p.context_amount * sum(old_sz)
    hc_z = old_sz[0] + p.context_amount * sum(old_sz)
    
    s_z = round(np.sqrt(wc_z * hc_z))
    s_z = min(s_z, min(state['im_h'], state['im_w']))
    scale_z = p.exemplar_size / s_z
    d_search = (p.instance_size - p.exemplar_size) / 2
    pad = d_search / scale_z
    s_x = round(s_z + 2 * pad)

    #############################################################################
    ####                    for gobal tracking results  1
    #############################################################################    
    global_old_pos   = state_global['target_pos'] 
    global_p         = state_global['p']
    global_avg_chans = state_global['avg_chans']
    global_window    = state_global['window']
    global_old_sz    = state_global['target_sz']
    global_dev       = state_global['device']

    global_wc_z = global_old_sz[1] + global_p.context_amount * sum(global_old_sz)
    global_hc_z = global_old_sz[0] + global_p.context_amount * sum(global_old_sz)
    
    global_s_z = round(np.sqrt(global_wc_z * global_hc_z))
    global_s_z = min(global_s_z, min(state_global['im_h'], state_global['im_w']))
    global_scale_z = global_p.exemplar_size / global_s_z
    global_d_search = (global_p.instance_size - global_p.exemplar_size) / 2
    global_pad = global_d_search / global_scale_z
    global_s_x = round(global_s_z + 2 * global_pad)


    #############################################################################
    ####                    for gobal tracking results  2 
    #############################################################################    
    global_old_pos1   = state_global_1['target_pos'] 
    global_p1         = state_global_1['p']
    global_avg_chans1 = state_global_1['avg_chans']
    global_window1    = state_global_1['window']
    global_old_sz1    = state_global_1['target_sz']
    global_dev1       = state_global_1['device']

    global_wc_z1 = global_old_sz1[1] + global_p1.context_amount * sum(global_old_sz1)
    global_hc_z1 = global_old_sz1[0] + global_p1.context_amount * sum(global_old_sz1)
    
    global_s_z1 = round(np.sqrt(global_wc_z1 * global_hc_z1))
    global_s_z1 = min(global_s_z1, min(state_global_1['im_h'], state_global_1['im_w']))
    global_scale_z1 = global_p1.exemplar_size / global_s_z1
    global_d_search1 = (global_p1.instance_size - global_p1.exemplar_size) / 2
    global_p1ad1 = global_d_search1 / global_scale_z1
    global_s_x1 = round(global_s_z1 + 2 * global_p1ad1)





    state['frameIdx'] = state['frameIdx'] + 1 
    
    #########################################################################################
    ####                            Local Search Region                                      
    #########################################################################################
    # extract scaled crops for search region x at previous target position
    x_crop = Variable(get_subwindow_tracking(im, old_pos, p.instance_size, round(s_x), avg_chans).unsqueeze(0))  
    ## x_crop: torch.Size([1, 3, 271, 271]) 
    target_pos, target_sz, score, short_long_templates_img = temp_mem.batch_evaluate(state, im, x_crop.to(dev), old_pos, old_sz * scale_z, window, scale_z, p) 


    global_x_crop = Variable(get_subwindow_tracking(im, global_old_pos, global_p.instance_size, round(global_s_x), avg_chans).unsqueeze(0))  
    sel_target_pos_G, sel_target_sz_G, sel_score_G, global_x_crop = temp_mem.batch_evaluate(state, im, global_x_crop.to(dev), \
                            global_old_pos, global_old_sz * global_scale_z, global_window, global_scale_z, global_p) 


    global_x_crop1 = Variable(get_subwindow_tracking(im, global_old_pos1, global_p1.instance_size, round(global_s_x1), avg_chans).unsqueeze(0))  
    sel_target_pos_G1, sel_target_sz_G1, sel_score_G1, global_x_crop1 = temp_mem.batch_evaluate(state, im, global_x_crop1.to(dev), \
                            global_old_pos1, global_old_sz1 * global_scale_z1, global_window1, global_scale_z1, global_p1) 



    #########################################################################################
    ####                            Global Search Region 
    #########################################################################################
    if sel_score_G < 0.6:
        state['failue_times'] = state['failue_times'] + 1 
    else: 
        state['failue_times'] = 0 

    # if sel_score_G1 < 0.6: 
    if sel_score_G1 < 0.7: 
        state_global_1['failue_times'] =  state_global_1['failue_times'] + 1  
    else: 
        state_global_1['failue_times'] = 0  
        
    always_use_globalAttention = True 
    delta_ = 0 
    


    if always_use_globalAttention: 

        temp_DIR_TO_SAVE = './temp_DIR_TO_SAVE_static_Global_attentionMap/'+state['videoName']+"/"
        if not os.path.exists(temp_DIR_TO_SAVE):
            os.makedirs(temp_DIR_TO_SAVE)            

        atttenton_BBox = [] 
        dynamic_atttentonMAP_list = [] 
        conserve_attention_centerLoc = [] 
        wide_attention_centerLoc = []

        # for j in range(len(short_long_templates_img)): 
        for j in range(2): 
            targetObject_template = short_long_templates_img[j] 
            # targetObject_template = targetObject_template[20:100, 20:100, :]
            # cv2.imwrite('./targetObject_template.png', targetObject_template) 
            
            # pdb.set_trace() 
            # dynamic_atttentonMAP_v2 = predict(dcynet_Generator, im, np.array(targetObject_template)) 
            # cv2.imwrite('./dynamic_atttentonMAP_v2.png', dynamic_atttentonMAP_v2) 

            im_trans   = to_tensor(im) 
            t_template = to_tensor(targetObject_template.astype(np.uint8))
            # t_template = to_tensor(np.array(targetObject_template)) 


            im_trans = cv2.resize(im, (300, 300))
            t_template = cv2.resize(targetObject_template, (100, 100)) 

            im_trans = to_variable(torch.unsqueeze(to_tensor(im_trans), dim=0), False)
            t_template = to_variable(torch.unsqueeze(to_tensor(t_template), dim=0), False) 

            coords = torch.from_numpy(old_pos) 
            coords = coords.unsqueeze(0).type(torch.FloatTensor) 


            out = dcynet_adais_Generator(im_trans, t_template, coords)
            out = nn.functional.interpolate(out, size=[im.shape[0], im.shape[1]])
            map_out = out.cpu().data.squeeze(0)
            pilTrans = transforms.ToPILImage()
            pilImg = pilTrans(map_out) 
            dynamic_atttentonMAP = np.asarray(pilImg)
            dynamic_atttentonMAP = cv2.resize(dynamic_atttentonMAP, (im.shape[1], im.shape[0]))
            state['atttentonMAP'] = dynamic_atttentonMAP
            
            # cv2.imwrite(temp_DIR_TO_SAVE+str(state['frameIdx'])+'_dynamic_atttentonMAP_adaptIS.png', dynamic_atttentonMAP) 
            
            # pdb.set_trace() 

            dynamic_atttentonMAP_list.append(dynamic_atttentonMAP)

            # dynamic_atttentonMAP_list = np.array(dynamic_atttentonMAP_list)     ## (7, 1080, 1920) 
            # cv2.imwrite('./'+str(j)+'_fused_mean_atttentonMAP_adaptIS.png', dynamic_atttentonMAP_list[0]) 

            # mean_atttentonMAP = dynamic_atttentonMAP_list.mean(0) 
            # cv2.imwrite('./'+str(j)+'_fused_mean_atttentonMAP_adaptIS.png', mean_atttentonMAP) 
            
            # pdb.set_trace() 
            ret, static_atttentonMAP = cv2.threshold(dynamic_atttentonMAP, 5, 255, cv2.THRESH_BINARY)
            label_image = measure.label(static_atttentonMAP)
            props = measure.regionprops(label_image)
            
            similarity_glob_target_max = 0 
            #### for each candidate search region. 
            for i in range(len(props)):
                center_position = props[i].centroid 
                center_position = [int(center_position[1]), int(center_position[0])]   
                wide_attention_centerLoc.append(center_position) 

                bbox = props[i].bbox 

                dist_x = global_old_pos[0] - center_position[0] 
                dist_y = global_old_pos[1] - center_position[1] 
                all_dist = dist_x + dist_y 

                # pdb.set_trace() 
                if bbox[2] > 5 and bbox[3] > 5: 
                    atttenton_BBox.append(bbox)
                    conserve_attention_centerLoc.append(center_position) 



            if state['failue_times'] > 5: 
                state['failue_times'] = 0 
                ############################################################
                if 0 < len(conserve_attention_centerLoc) <= 1: 
                    global_curr_pos = np.array(conserve_attention_centerLoc[0]) 
                    global_x_crop = Variable(get_subwindow_tracking(im, global_curr_pos, global_p.instance_size, round(global_s_x), avg_chans).unsqueeze(0))  ## x_crop: torch.Size([1, 3, 271, 271]) 
                    sel_target_pos_G, sel_target_sz_G, sel_score_G, short_long_templates_img_G = \
                                temp_mem.batch_evaluate(state, im, global_x_crop.to(dev), global_curr_pos, global_old_sz * global_scale_z, window, global_scale_z, global_p) 
                else: 
                    max_score_G = 0 
                    for idex in range(len(conserve_attention_centerLoc)):
                        global_curr_pos = np.array(conserve_attention_centerLoc[idex])
                        global_x_crop = Variable(get_subwindow_tracking(im, global_curr_pos, global_p.instance_size, round(global_s_x), avg_chans).unsqueeze(0))  ## x_crop: torch.Size([1, 3, 271, 271]) 
                        target_pos_G, target_sz_G, score_G, short_long_templates_img_G = \
                                temp_mem.batch_evaluate(state, im, global_x_crop.to(dev), global_curr_pos, global_old_sz * global_scale_z, window, global_scale_z, global_p) 

                        if max_score_G < score_G: 
                            sel_target_pos_G, sel_target_sz_G, sel_score_G = target_pos_G, target_sz_G, score_G 
                            max_score_G = score_G 
            

            if state_global_1['failue_times'] > 3: 
                state_global_1['failue_times'] = 0 
                ############################################################
                if 0 < len(conserve_attention_centerLoc) <= 1: 
                    global_curr_pos_1 = np.array(conserve_attention_centerLoc[0]) 
                    global_x_crop1 = Variable(get_subwindow_tracking(im, global_curr_pos_1, global_p.instance_size, round(global_s_x), avg_chans).unsqueeze(0))  ## x_crop: torch.Size([1, 3, 271, 271]) 
                    sel_target_pos_G1, sel_target_sz_G1, sel_score_G1, global_x_crop1 = \
                                temp_mem.batch_evaluate(state_global_1, im, global_x_crop1.to(dev), global_curr_pos_1, global_old_sz1 * global_scale_z1, window, global_scale_z1, global_p1) 

                else: 
                    max_score_G1 = 0 
                    for idex in range(len(conserve_attention_centerLoc)):
                        global_curr_pos_1 = np.array(conserve_attention_centerLoc[idex])
                        global_x_crop1 = Variable(get_subwindow_tracking(im, global_curr_pos_1, global_p.instance_size, round(global_s_x), avg_chans).unsqueeze(0))  ## x_crop: torch.Size([1, 3, 271, 271]) 
                        target_pos_G1, target_sz_G1, score_G1, short_long_templates_img_G = \
                                temp_mem.batch_evaluate(state_global_1, im, global_x_crop1.to(dev), global_curr_pos_1, global_old_sz1 * global_scale_z1, window, global_scale_z1, global_p1) 

                        if max_score_G1 < score_G1: 
                            sel_target_pos_G1, sel_target_sz_G1, sel_score_G1 = target_pos_G1, target_sz_G1, score_G1 
                            max_score_G1 = score_G1




    #### local version ####    
    #### normalize the target position. 
    target_pos[0] = max(0,  min(state['im_w'], target_pos[0]))
    target_pos[1] = max(0,  min(state['im_h'], target_pos[1]))
    target_sz[0]  = max(10, min(state['im_w'], target_sz[0]))
    target_sz[1]  = max(10, min(state['im_h'], target_sz[1]))
    state['target_pos'] = target_pos
    state['target_sz'] = target_sz
    state['score'] = score
    state['crop'] = x_crop 


    #### global version ####
    sel_target_pos_G[0] = max(0,  min(state_global['im_w'], sel_target_pos_G[0]))
    sel_target_pos_G[1] = max(0,  min(state_global['im_h'], sel_target_pos_G[1]))
    sel_target_sz_G[0]  = max(10, min(state_global['im_w'], sel_target_sz_G[0]))
    sel_target_sz_G[1]  = max(10, min(state_global['im_h'], sel_target_sz_G[1]))
    state_global['target_pos'] = sel_target_pos_G
    state_global['target_sz'] = sel_target_sz_G
    state_global['score'] = sel_score_G
    state_global['crop'] = global_x_crop 
    
    sel_target_pos_G1[0] = max(0,  min(state_global_1['im_w'], sel_target_pos_G1[0]))
    sel_target_pos_G1[1] = max(0,  min(state_global_1['im_h'], sel_target_pos_G1[1]))
    sel_target_sz_G1[0]  = max(10, min(state_global_1['im_w'], sel_target_sz_G1[0]))
    sel_target_sz_G1[1]  = max(10, min(state_global_1['im_h'], sel_target_sz_G1[1]))
    state_global_1['target_pos'] = sel_target_pos_G1
    state_global_1['target_sz'] = sel_target_sz_G1
    state_global_1['score'] = sel_score_G1
    state_global_1['crop'] = global_x_crop1  
    
    
    return state, state_global, state_global_1 



