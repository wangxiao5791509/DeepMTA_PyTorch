import cv2
import sys, os, glob, re
import json
from os.path import join, dirname, abspath, realpath, isdir
from os import makedirs
import numpy as np
from shutil import rmtree
from ipdb import set_trace
from .bench_utils.bbox_helper import rect_2_cxy_wh, cxy_wh_2_rect

import torch 
from network import traj_critic   
import torchvision 
import warnings
warnings.filterwarnings("ignore")
import torchvision.transforms as transforms
to_tensor = transforms.ToTensor()

import pdb 

critic_path = "/home/wangxiao/Documents/deepMTA_project/DeepMTA_TCSVT_project/49_traj_critic_net.pkl"
traj_critic_net = traj_critic()
traj_critic_net = traj_critic_net.cuda() 
traj_critic_net.load_state_dict(torch.load(critic_path))

print(traj_critic_net)



def center_error(rects1, rects2):
    """Center error.
    Args:
        rects1 (numpy.ndarray): An N x 4 numpy array, each line represent a rectangle
            (left, top, width, height).
        rects2 (numpy.ndarray): An N x 4 numpy array, each line represent a rectangle
            (left, top, width, height).
    """
    centers1 = rects1[..., :2] + (rects1[..., 2:] - 1) / 2
    centers2 = rects2[..., :2] + (rects2[..., 2:] - 1) / 2
    errors = np.sqrt(np.sum(np.power(centers1 - centers2, 2), axis=-1))

    return errors

def _intersection(rects1, rects2):
    r"""Rectangle intersection.
    Args:
        rects1 (numpy.ndarray): An N x 4 numpy array, each line represent a rectangle
            (left, top, width, height).
        rects2 (numpy.ndarray): An N x 4 numpy array, each line represent a rectangle
            (left, top, width, height).
    """
    assert rects1.shape == rects2.shape
    x1 = np.maximum(rects1[..., 0], rects2[..., 0])
    y1 = np.maximum(rects1[..., 1], rects2[..., 1])
    x2 = np.minimum(rects1[..., 0] + rects1[..., 2],
                    rects2[..., 0] + rects2[..., 2])
    y2 = np.minimum(rects1[..., 1] + rects1[..., 3],
                    rects2[..., 1] + rects2[..., 3])

    w = np.maximum(x2 - x1, 0)
    h = np.maximum(y2 - y1, 0)

    return np.stack([x1, y1, w, h]).T

def rect_iou(rects1, rects2, bound=None):
    r"""Intersection over union.
    Args:
        rects1 (numpy.ndarray): An N x 4 numpy array, each line represent a rectangle
            (left, top, width, height).
        rects2 (numpy.ndarray): An N x 4 numpy array, each line represent a rectangle
            (left, top, width, height).
        bound (numpy.ndarray): A 4 dimensional array, denotes the bound
            (min_left, min_top, max_width, max_height) for ``rects1`` and ``rects2``.
    """
    assert rects1.shape == rects2.shape
    if bound is not None:
        # bounded rects1
        rects1[:, 0] = np.clip(rects1[:, 0], 0, bound[0])
        rects1[:, 1] = np.clip(rects1[:, 1], 0, bound[1])
        rects1[:, 2] = np.clip(rects1[:, 2], 0, bound[0] - rects1[:, 0])
        rects1[:, 3] = np.clip(rects1[:, 3], 0, bound[1] - rects1[:, 1])
        # bounded rects2
        rects2[:, 0] = np.clip(rects2[:, 0], 0, bound[0])
        rects2[:, 1] = np.clip(rects2[:, 1], 0, bound[1])
        rects2[:, 2] = np.clip(rects2[:, 2], 0, bound[0] - rects2[:, 0])
        rects2[:, 3] = np.clip(rects2[:, 3], 0, bound[1] - rects2[:, 1])

    rects_inter = _intersection(rects1, rects2)
    areas_inter = np.prod(rects_inter[..., 2:], axis=-1)

    areas1 = np.prod(rects1[..., 2:], axis=-1)
    areas2 = np.prod(rects2[..., 2:], axis=-1)
    areas_union = areas1 + areas2 - areas_inter

    eps = np.finfo(float).eps
    ious = areas_inter / (areas_union + eps)
    ious = np.clip(ious, 0.0, 1.0)

    return ious

def overlap_ratio(rect1, rect2):
    '''
    Compute overlap ratio between two rects
    - rect: 1d array of [x,y,w,h] or
            2d array of N x [x,y,w,h]
    '''

    if rect1.ndim==1:
        rect1 = rect1[None,:]
    if rect2.ndim==1:
        rect2 = rect2[None,:]

    left = np.maximum(rect1[:,0], rect2[:,0])
    right = np.minimum(rect1[:,0]+rect1[:,2], rect2[:,0]+rect2[:,2])
    top = np.maximum(rect1[:,1], rect2[:,1])
    bottom = np.minimum(rect1[:,1]+rect1[:,3], rect2[:,1]+rect2[:,3])

    intersect = np.maximum(0,right - left) * np.maximum(0,bottom - top)
    union = rect1[:,2]*rect1[:,3] + rect2[:,2]*rect2[:,3] - intersect
    iou = np.clip(intersect / union, 0, 1)
    return iou

def calc_curves(ious, center_errors, nbins_iou, nbins_ce):
    ious = np.asarray(ious, float)[:, np.newaxis]
    center_errors = np.asarray(center_errors, float)[:, np.newaxis]

    thr_iou = np.linspace(0, 1, nbins_iou)[np.newaxis, :]
    thr_ce = np.arange(0, nbins_ce)[np.newaxis, :]

    bin_iou = np.greater(ious, thr_iou)
    bin_ce = np.less_equal(center_errors, thr_ce)

    succ_curve = np.mean(bin_iou, axis=0)
    prec_curve = np.mean(bin_ce, axis=0)

    return succ_curve, prec_curve

def compute_success_overlap(gt_bb, result_bb):
    thresholds_overlap = np.arange(0, 1.05, 0.05)
    n_frame = len(gt_bb)
    success = np.zeros(len(thresholds_overlap))
    iou = overlap_ratio(gt_bb, result_bb)
    for i in range(len(thresholds_overlap)):
        success[i] = sum(iou > thresholds_overlap[i]) / float(n_frame)
    return success

def compute_success_error(gt_center, result_center):
    thresholds_error = np.arange(0, 51, 1)
    n_frame = len(gt_center)
    success = np.zeros(len(thresholds_error))
    dist = np.sqrt(np.sum(np.power(gt_center - result_center, 2), axis=1))
    for i in range(len(thresholds_error)):
        success[i] = sum(dist <= thresholds_error[i]) / float(n_frame)
    return success

def get_result_bb(arch, seq):
    result_path = join(arch, seq + '.txt')
    temp = np.loadtxt(result_path, delimiter=',').astype(np.float)
    return np.array(temp)

def convert_bb_to_center(bboxes):
    return np.array([(bboxes[:, 0] + (bboxes[:, 2] - 1) / 2),
                     (bboxes[:, 1] + (bboxes[:, 3] - 1) / 2)]).T






def test_uav123(v_id, tracker, video, args):

    toc, regions, regions_global, regions_global1 = 0, [], [], []  
    image_files, gt, videoName = video['img_names'], video['gt_rect'], video['video_dir'] 
    got10k_dataset_path = "/home/wangxiao/Documents/deepMTA_project/DeepMTA_TCSVT_project/data/UAV123/"
    
    traj_score_baseline = 0 
    traj_score_GlobalAtt = 0 
    traj_score_GlobalAtt_1 = 0
    
    video_path = join('benchmark/results/', args.dataset, args.save_path)
    if not isdir(video_path): makedirs(video_path)
    
    already_tracking_datasets = os.listdir(video_path) 

    ###################################################################################################
    ####                                Tracking Procedure 
    ###################################################################################################    
    if videoName in already_tracking_datasets: 
        print("==>> skipping video: ", videoName) 
    else: 
        print("==>> tracking video: ", videoName) 

        #######################################################################
        ####                    For the first frame 
        #######################################################################
        f = 0 
        im = cv2.imread(got10k_dataset_path+image_files[f]) 
        #### transform gt into [cx, cy, width, height]
        init_bbox = gt[f] 
        init_pos, init_sz = rect_2_cxy_wh(gt[f])        ## init_pos: array([ 86.5, 136.5]) init_size: array([29, 23])
        state, state_global, state_global_1 = tracker.setup(im, init_pos, init_sz, videoName, f)
        location = gt[f]
        location_global = gt[f] 
        regions.append(gt[f])
        regions_global.append(gt[f]) 
        regions_global1.append(gt[f]) 
        
        clip_len = 10 
        img_size = 300 

        init_target = im[int(init_bbox[1]):int(init_bbox[1]+init_bbox[3]), int(init_bbox[0]):int(init_bbox[0]+init_bbox[2]), :]
        init_target = cv2.resize(init_target, (img_size, img_size), interpolation=cv2.INTER_CUBIC)

        image_list      = torch.zeros(clip_len, 3, img_size, img_size)
        initTarget_list = torch.zeros(clip_len, 3, img_size, img_size)
        attMap_list     = torch.zeros(clip_len, 3, img_size, img_size)

        targetImg1_list = torch.zeros(clip_len, 3, img_size, img_size)
        targetMap1_list = torch.zeros(clip_len, 3, img_size, img_size)
        trajScore1_list = torch.zeros(clip_len, 1)
        trajBBox1_list  = torch.zeros(clip_len, 4)

        targetImg2_list = torch.zeros(clip_len, 3, img_size, img_size)
        targetMap2_list = torch.zeros(clip_len, 3, img_size, img_size)
        trajScore2_list = torch.zeros(clip_len, 1)
        trajBBox2_list  = torch.zeros(clip_len, 4)

        targetImg3_list = torch.zeros(clip_len, 3, img_size, img_size)
        targetMap3_list = torch.zeros(clip_len, 3, img_size, img_size)
        trajScore3_list = torch.zeros(clip_len, 1)
        trajBBox3_list  = torch.zeros(clip_len, 4)


        score_list_1 = []
        score_list_2 = []
        score_list_3 = []        

        score_list_1.append( state['score'] )  
        score_list_2.append( state_global['score'] )  
        score_list_3.append( state_global_1['score'] )  


        #######################################################################
        ####                    For the rest frame                             
        #######################################################################
        # for f, image_file in enumerate(image_files):
        for f in range(1, len(image_files)): 

            im = cv2.imread(got10k_dataset_path+image_files[f]) 
            tic = cv2.getTickCount()

            state, state_global, state_global_1 = tracker.track(im, state, state_global, state_global_1)

            location         = cxy_wh_2_rect(state['target_pos'], state['target_sz'])
            location_global  = cxy_wh_2_rect(state_global['target_pos'], state_global['target_sz'])
            location_global1 = cxy_wh_2_rect(state_global_1['target_pos'], state_global_1['target_sz'])


            #### BBox location 
            regions.append(location)
            regions_global.append(location_global) 
            regions_global1.append(location_global1) 

            #### Calculate the total score 
            traj_score_baseline    = traj_score_baseline +  state['score'] 
            traj_score_GlobalAtt   = traj_score_GlobalAtt + state_global['score'] 
            traj_score_GlobalAtt_1 = traj_score_GlobalAtt_1 + state_global_1['score'] 

            score_list_1.append( state['score'] )  
            score_list_2.append( state_global['score'] )  
            score_list_3.append( state_global_1['score'] )  

            toc += cv2.getTickCount() - tic

            if args.viz and f > 0:  # visualization
                if f == 0: cv2.destroyAllWindows()

                # pdb.set_trace() 

                # if len(gt[f]) == 8:
                #     cv2.polylines(im, [np.array(gt[f], np.int).reshape((-1, 1, 2))], True, (0, 255, 0), 3)
                # else:
                #     # cv2.rectangle(im, (gt[f, 0], gt[f, 1]), (gt[f, 0] + gt[f, 2], gt[f, 1] + gt[f, 3]), (0, 255, 0), 3)
                #     cv2.rectangle(im, (int(gt[f][0]), int(gt[f][1])), (int(gt[f][0]) + int(gt[f][2]), int(gt[f][1]) + int(gt[f][3])), (0, 255, 0), 2)


                if len(location) == 8:
                    cv2.polylines(im, [location.reshape((-1, 1, 2))], True, (0, 255, 255), 3)
                else:
                    location = [int(l) for l in location]
                    location_global = [int(l) for l in location_global]
                    location_global1 = [int(l) for l in location_global1]

                    cv2.rectangle(im, (location[0], location[1]),(location[0] + location[2], location[1] + location[3]), (0, 255, 255), 2)
                    cv2.rectangle(im, (location_global[0], location_global[1]),(location_global[0] + \
                                    location_global[2], location_global[1] + location_global[3]), (0, 0, 255), 2)
                    cv2.rectangle(im, (location_global1[0], location_global1[1]),(location_global1[0] + \
                                    location_global1[2], location_global1[1] + location_global1[3]), (0, 100, 0), 2)

                cv2.putText(im, "score-THOR: {:.4f}".format(state['score']), (40, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2) 
                cv2.putText(im, "score-G1: {:.4f}".format(state_global['score']), (40, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(im, "score-G2: {:.4f}".format(state_global_1['score']), (40, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 100, 0), 2)

                cv2.imshow(video['video_dir'], im)
                cv2.moveWindow(video['video_dir'], 200, 50)
                cv2.waitKey(1)

        cv2.destroyAllWindows()
        toc /= cv2.getTickFrequency() 

        result_path = join(video_path, '{:s}_THOR-baseline-uav123.txt'.format(video['video_dir']))
        with open(result_path, "w") as fin:
            for x in regions:
                fin.write(','.join([str(i) for i in x])+'\n')





        # #######################################################################
        # ####                    Trajectory  Evaluation                              
        # #######################################################################
        clip_num = len(image_files) // clip_len 
        rest_frameNUM = len(image_files) % clip_len 

        traj_1_criticScore = 0 
        traj_2_criticScore = 0 
        traj_3_criticScore = 0  

        for clip_index in range(clip_num): 

            start_index = clip_index * clip_len 
            end_index   = start_index + clip_len 
            
            count = 0 
            for frameIndex in range(start_index, end_index):
                im = cv2.imread(got10k_dataset_path + image_files[frameIndex]) 

                location         = regions[frameIndex]
                location_global  = regions_global[frameIndex]
                location_global1 = regions_global1[frameIndex]

                location[0] = max(0,  min(state['im_w'], location[0]))
                location[1] = max(0,  min(state['im_h'], location[1]))
                location[2] = max(10, min(state['im_w'], location[2]))
                location[3] = max(10, min(state['im_h'], location[3]))

                location_global[0] = max(0,  min(state['im_w'], location_global[0]))
                location_global[1] = max(0,  min(state['im_h'], location_global[1]))
                location_global[2] = max(10, min(state['im_w'], location_global[2]))
                location_global[3] = max(10, min(state['im_h'], location_global[3]))

                location_global1[0] = max(0,  min(state['im_w'], location_global1[0]))
                location_global1[1] = max(0,  min(state['im_h'], location_global1[1]))
                location_global1[2] = max(10, min(state['im_w'], location_global1[2]))
                location_global1[3] = max(10, min(state['im_h'], location_global1[3]))


                targetPatch_1 = im[int(location[1]):int(location[1]+location[3]), int(location[0]):int(location[0]+location[2]), :]
                targetPatch_2 = im[int(location_global[1]):int(location_global[1]+location_global[3]), int(location_global[0]):int(location_global[0]+location_global[2]), :]
                targetPatch_3 = im[int(location_global1[1]):int(location_global1[1]+location_global1[3]), int(location_global1[0]):int(location_global1[0]+location_global1[2]), :]

                # cv2.imwrite("./temp_DIR_TO_SAVE_localPatch/"+str(f)+'_targetPatch_1.png', targetPatch_1) 
                # cv2.imwrite("./temp_DIR_TO_SAVE_localPatch/"+str(f)+'_targetPatch_2.png', targetPatch_2) 
                # cv2.imwrite("./temp_DIR_TO_SAVE_localPatch/"+str(f)+'_targetPatch_3.png', targetPatch_3) 

                attentionPath = "/home/wangxiao/Documents/deepMTA_project/DeepMTA_TCSVT_project/temp_DIR_TO_SAVE_static_Global_attentionMap/"
                attentionPath_ = attentionPath + videoName + "/"

                if frameIndex < len(image_files)-1: 
                    attentionPath_imgpath = attentionPath_ + str(frameIndex+1)+"_dynamic_atttentonMAP_adaptIS.png"
                else: 
                    # print("--------->>>> Beyond ... ")
                    attentionPath_imgpath = attentionPath_ + str(frameIndex)+"_dynamic_atttentonMAP_adaptIS.png"

                attenMap = cv2.imread(attentionPath_imgpath) 

                attenPatch_1 = attenMap[int(location[1]):int(location[1]+location[3]), int(location[0]):int(location[0]+location[2])]
                attenPatch_2 = attenMap[int(location_global[1]):int(location_global[1]+location_global[3]), int(location_global[0]):int(location_global[0]+location_global[2])]
                attenPatch_3 = attenMap[int(location_global1[1]):int(location_global1[1]+location_global1[3]), int(location_global1[0]):int(location_global1[0]+location_global1[2])]

                # cv2.imwrite("./temp_DIR_TO_SAVE_localPatch/"+str(f)+'_1_target_atttentonMAP_adaptIS.png', attenPatch_1) 
                # cv2.imwrite("./temp_DIR_TO_SAVE_localPatch/"+str(f)+'_2_target_atttentonMAP_adaptIS.png', attenPatch_2) 
                # cv2.imwrite("./temp_DIR_TO_SAVE_localPatch/"+str(f)+'_3_target_atttentonMAP_adaptIS.png', attenPatch_3) 
                
                # print(location_global)  
                attenPatch_1 = cv2.resize(attenPatch_1, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
                attenPatch_2 = cv2.resize(attenPatch_2, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
                attenPatch_3 = cv2.resize(attenPatch_3, (img_size, img_size), interpolation=cv2.INTER_CUBIC)

                targetPatch_1 = cv2.resize(targetPatch_1, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
                targetPatch_2 = cv2.resize(targetPatch_2, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
                targetPatch_3 = cv2.resize(targetPatch_3, (img_size, img_size), interpolation=cv2.INTER_CUBIC)

                image    = cv2.resize(im, (img_size, img_size), interpolation=cv2.INTER_CUBIC) 
                attenMap = cv2.resize(attenMap, (img_size, img_size), interpolation=cv2.INTER_CUBIC) 


                initTarget_list[count] = to_tensor(init_target)
                image_list[count]      = to_tensor(image)  
                attMap_list[count]     = to_tensor(attenMap)

                targetImg1_list[count] = to_tensor(targetPatch_1)
                targetMap1_list[count] = to_tensor(attenPatch_1)
                trajBBox1_list[count]  = torch.from_numpy(np.array(location))  
                trajScore1_list[count] = score_list_1[frameIndex] 

                targetImg2_list[count] = to_tensor(targetPatch_2)
                targetMap2_list[count] = to_tensor(attenPatch_2)
                trajBBox2_list[count]  = torch.from_numpy(np.array(location_global))  
                trajScore2_list[count] = score_list_2[frameIndex] 

                targetImg3_list[count] = to_tensor(targetPatch_3)
                targetMap3_list[count] = to_tensor(attenPatch_3)
                trajBBox3_list[count]  = torch.from_numpy(np.array(location_global1))   
                trajScore3_list[count] = score_list_3[frameIndex] 

                count = count + 1 

            pred_traj_score1 = traj_critic_net(image_list, attMap_list, targetImg1_list, targetMap1_list, initTarget_list, trajBBox1_list, trajScore1_list)
            pred_traj_score1 = pred_traj_score1.item() 
            pred_traj_score2 = traj_critic_net(image_list, attMap_list, targetImg2_list, targetMap2_list, initTarget_list, trajBBox2_list, trajScore2_list)
            pred_traj_score2 = pred_traj_score2.item() 
            pred_traj_score3 = traj_critic_net(image_list, attMap_list, targetImg3_list, targetMap3_list, initTarget_list, trajBBox3_list, trajScore3_list)
            pred_traj_score3 = pred_traj_score3.item() 


            #### 
            traj_1_criticScore = traj_1_criticScore + pred_traj_score1
            traj_2_criticScore = traj_2_criticScore + pred_traj_score2 
            traj_3_criticScore = traj_3_criticScore + pred_traj_score3 


        traj_1_criticScore = traj_1_criticScore * 0.3 + traj_score_baseline
        traj_2_criticScore = traj_2_criticScore * 0.3 + traj_score_GlobalAtt 
        traj_3_criticScore = traj_3_criticScore * 0.3 + traj_score_GlobalAtt_1 

        
        # save result
        video_path = join('benchmark/results/', args.dataset, args.save_path, video['video_dir'])
        if not isdir(video_path): makedirs(video_path)

        print("==>> trajectory Score of baseline && GlobalAtt: ", traj_score_baseline, "    ", traj_score_GlobalAtt)
        if traj_1_criticScore >= traj_2_criticScore and traj_1_criticScore >= traj_3_criticScore: 
            print("==>> The baseline result is chosen as the final Tracking results .... ")
            result_path = join(video_path, '{:s}_Ours.txt'.format(video['video_dir']))
            with open(result_path, "w") as fin:
                for x in regions:
                    fin.write(','.join([str(i) for i in x])+'\n')

        
        elif traj_2_criticScore >= traj_1_criticScore and traj_2_criticScore >= traj_3_criticScore: 
            print("==>> The Global Attention-I .... ")
            result_path = join(video_path, '{:s}_Ours.txt'.format(video['video_dir']))
            with open(result_path, "w") as fin:
                for x in regions_global:
                    fin.write(','.join([str(i) for i in x])+'\n')


        elif traj_3_criticScore >= traj_1_criticScore and traj_3_criticScore >= traj_2_criticScore: 
            print("==>> The Global Attention-II .... ")
            result_path = join(video_path, '{:s}_Ours.txt'.format(video['video_dir']))
            with open(result_path, "w") as fin:
                for x in regions_global1:
                    fin.write(','.join([str(i) for i in x])+'\n')








def eval_uav123(save_path, delete_after):
    base_path = join(realpath(dirname(__file__)), '../data', 'TC128')
    json_path = base_path + '.json'
    annos = json.load(open(json_path, 'r'))
    seqs = list(annos.keys())

    video_path = join('benchmark/results/TC128/', save_path)
    trackers = glob.glob(join(video_path))
    _, _, files = next(os.walk(trackers[0]))
    num_files = len(files)

    thresholds_overlap = np.arange(0, 1.05, 0.05)
    success_overlap = np.zeros((num_files, len(trackers), len(thresholds_overlap)))

    thresholds_error = np.arange(0, 51, 1)
    success_error = np.zeros((num_files, len(trackers), len(thresholds_error)))

    for i, f in enumerate(files):
        seq = f.replace('.txt', '')
        gt_rect = np.array(annos[seq]['gt_rect']).astype(np.float)
        gt_center = convert_bb_to_center(gt_rect)
        for j in range(len(trackers)):
            tracker = trackers[j]
            bb = get_result_bb(tracker, seq)
            center = convert_bb_to_center(bb)
            success_overlap[i][j] = compute_success_overlap(gt_rect, bb)
            success_error[i][j] = compute_success_error(gt_center, center)

    max_auc = 0.0
    max_prec = 0.0
    for i in range(len(trackers)):
        auc = success_overlap[:, i, :].mean()
        if auc > max_auc:
            max_auc = auc

        prec = success_error[:, i, :].mean()
        if prec > max_prec:
            max_prec = prec

    if delete_after:
        rmtree(trackers[0])

    return {'auc': max_auc, 'precision': prec}


